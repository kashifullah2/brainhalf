import { DatabaseSync } from 'node:sqlite';
import { existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, '..', 'data');

if (!existsSync(DATA_DIR)) {
  mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = process.env.STOCKROOM_DB || join(DATA_DIR, 'stockroom.db');

let db;

export function getDb() {
  if (!db) {
    db = new DatabaseSync(DB_PATH);
    db.exec('PRAGMA journal_mode=WAL');
    db.exec('PRAGMA foreign_keys=ON');
    db.exec('PRAGMA busy_timeout=5000');
    initSchema();
    seedIfEmpty();
  }
  return db;
}

function initSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      sku         TEXT    NOT NULL UNIQUE,
      name        TEXT    NOT NULL,
      category    TEXT    NOT NULL,
      stock       INTEGER NOT NULL CHECK(stock >= 0),
      price_cents INTEGER NOT NULL CHECK(price_cents >= 0),
      version     INTEGER NOT NULL DEFAULT 1,
      created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
      updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS reservations (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id      INTEGER NOT NULL REFERENCES products(id),
      customer_name   TEXT    NOT NULL,
      customer_email  TEXT    NOT NULL,
      quantity        INTEGER NOT NULL CHECK(quantity > 0),
      status          TEXT    NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','cancelled')),
      idempotency_key TEXT    UNIQUE,
      created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
      updated_at      TEXT    NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS audit_log (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      entity_type TEXT NOT NULL,
      entity_id   INTEGER NOT NULL,
      action      TEXT NOT NULL,
      actor       TEXT NOT NULL DEFAULT 'system',
      detail      TEXT,
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_reservations_idem ON reservations(idempotency_key);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id);
  `);
}

function seedIfEmpty() {
  const row = db.prepare('SELECT COUNT(*) as cnt FROM products').get();
  if (row.cnt === 0) {
    const insert = db.prepare(`
      INSERT INTO products (sku, name, category, stock, price_cents)
      VALUES (?, ?, ?, ?, ?)
    `);
    const seeds = [
      ['CAMERA-01', 'Camera',       'Electronics', 3, 2500],
      ['LENS-50MM', '50mm Lens',    'Electronics', 5, 1500],
      ['TRIPOD-02', 'Camera Tripod','Accessories', 8,  800],
    ];
    const logInsert = db.prepare(`
      INSERT INTO audit_log (entity_type, entity_id, action, detail)
      VALUES ('product', ?, 'created', ?)
    `);
    for (const [sku, name, category, stock, price_cents] of seeds) {
      const result = insert.run(sku, name, category, stock, price_cents);
      logInsert.run(result.lastInsertRowid, JSON.stringify({ sku, name, category, stock, price_cents }));
    }
    console.log('[db] Seeded 3 products.');
  }
}

export function withTransaction(db, operation) {
  db.exec('BEGIN IMMEDIATE');
  try { const result=operation(); db.exec('COMMIT'); return result; }
  catch (error) { try { db.exec('ROLLBACK'); } catch {} throw error; }
}

export function closeDb() { if (db) { db.close(); db=undefined; } }
