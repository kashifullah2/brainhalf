import { Router } from 'express';
import { getDb, withTransaction } from '../db.js';
const router=Router();
const full=(db,id)=>db.prepare(`SELECT r.*, p.name product_name, p.sku product_sku, p.price_cents FROM reservations r JOIN products p ON p.id=r.product_id WHERE r.id=?`).get(id);
const fail=(statusCode,message)=>{throw Object.assign(new Error(message),{statusCode})};
const positive=n=>Number.isSafeInteger(n)&&n>0;
function log(db,id,action,actor,detail){db.prepare("INSERT INTO audit_log (entity_type,entity_id,action,actor,detail) VALUES ('reservation',?,?,?,?)").run(id,action,actor,JSON.stringify(detail))}
router.get('/',(_req,res)=>{
 try{res.json(getDb().prepare('SELECT r.*, p.name product_name, p.sku product_sku, p.price_cents FROM reservations r JOIN products p ON p.id=r.product_id ORDER BY r.id DESC').all())}catch(e){res.status(500).json({message:e.message})}
});
router.post('/',(req,res)=>{
 try{
  const body=req.body??{};
  const {product_id,quantity,customer_name,customer_email}=body;
  if(!positive(product_id)||!positive(quantity))fail(400,'product_id and quantity must be positive integers');
  if(typeof customer_name!=='string'||!customer_name.trim())fail(400,'customer_name is required');
  if(typeof customer_email!=='string'||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer_email.trim()))fail(400,'customer_email must be a valid email address');
  const key=req.headers['idempotency-key']||null;
  if(key!==null&&(typeof key!=='string'||key.length>200))fail(400,'Idempotency-Key must contain at most 200 characters');
  const name=customer_name.trim(),email=customer_email.trim();const db=getDb();
  const result=withTransaction(db,()=>{
   if(key){const old=db.prepare('SELECT * FROM reservations WHERE idempotency_key=?').get(key);
    if(old){if(old.product_id!==product_id||old.quantity!==quantity||old.customer_name!==name||old.customer_email!==email)fail(409,'Idempotency-Key reuse with different payload is not allowed');return {status:200,body:full(db,old.id)}}}
   const product=db.prepare('SELECT * FROM products WHERE id=?').get(product_id);
   if(!product)fail(404,'Product not found');
   const changed=db.prepare("UPDATE products SET stock=stock-?, version=version+1, updated_at=datetime('now') WHERE id=? AND stock>=?").run(quantity,product_id,quantity);
   if(changed.changes!==1)fail(409,`Insufficient stock: requested ${quantity}, available ${product.stock}`);
   const added=db.prepare('INSERT INTO reservations (product_id,customer_name,customer_email,quantity,idempotency_key) VALUES (?,?,?,?,?)').run(product_id,name,email,quantity,key);
   log(db,added.lastInsertRowid,'created',email,{product_id,quantity,customer_name:name});
   return {status:201,body:full(db,added.lastInsertRowid)};
  });res.status(result.status).json(result.body);
 }catch(e){res.status(e.statusCode||500).json({message:e.message})}
});
for(const action of ['confirm','cancel'])router.post(`/:id/${action}`,(req,res)=>{
 try{const id=Number(req.params.id);if(!positive(id))fail(400,'Invalid reservation id');const db=getDb();
  const result=withTransaction(db,()=>{
   const row=db.prepare('SELECT * FROM reservations WHERE id=?').get(id);if(!row)fail(404,'Reservation not found');
   const target=action==='confirm'?'confirmed':'cancelled';if(row.status===target)return full(db,id);
   if(action==='confirm'&&row.status==='cancelled')fail(409,'Cannot confirm a cancelled reservation');
   db.prepare("UPDATE reservations SET status=?, updated_at=datetime('now') WHERE id=?").run(target,id);
   if(action==='cancel')db.prepare("UPDATE products SET stock=stock+?,version=version+1,updated_at=datetime('now') WHERE id=?").run(row.quantity,row.product_id);
   log(db,id,target,'staff',{reservation_id:id,...(action==='cancel'?{quantity_restored:row.quantity}:{})});return full(db,id);
  });res.json(result);
 }catch(e){res.status(e.statusCode||500).json({message:e.message})}
});
export default router;
