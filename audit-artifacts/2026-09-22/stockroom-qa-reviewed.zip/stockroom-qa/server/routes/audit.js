import { Router } from 'express';
import { getDb } from '../db.js';

const router = Router();

router.get('/', (req, res) => {
  try {
    const db = getDb();
    const { entity_type, entity_id, limit = 100, offset = 0 } = req.query;
    if (!Number.isSafeInteger(Number(limit)) || Number(limit)<1 || Number(limit)>1000 || !Number.isSafeInteger(Number(offset)) || Number(offset)<0 || (entity_id !== undefined && (!Number.isSafeInteger(Number(entity_id)) || Number(entity_id)<1))) return res.status(400).json({message:'Invalid audit pagination or entity ID'});
    let sql = 'SELECT * FROM audit_log WHERE 1=1';
    const params = [];
    if (entity_type) {
      sql += ' AND entity_type = ?';
      params.push(entity_type);
    }
    if (entity_id) {
      sql += ' AND entity_id = ?';
      params.push(Number(entity_id));
    }
    sql += ' ORDER BY id DESC LIMIT ? OFFSET ?';
    params.push(Number(limit), Number(offset));
    const rows = db.prepare(sql).all(...params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;