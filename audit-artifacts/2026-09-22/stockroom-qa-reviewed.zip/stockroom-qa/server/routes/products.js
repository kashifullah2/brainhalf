import { Router } from 'express';
import { getDb, withTransaction } from '../db.js';

const router = Router();



function validateProduct(body, requireAll = true) {
  const errors = [];
  const { sku, name, category, stock, price_cents } = body ?? {};

  if (requireAll || sku !== undefined) {
    if (!sku || typeof sku !== 'string' || sku.trim() === '')
      errors.push('sku is required and must be a non-empty string');
  }
  if (requireAll || name !== undefined) {
    if (!name || typeof name !== 'string' || name.trim() === '')
      errors.push('name is required and must be a non-empty string');
  }
  if (requireAll || category !== undefined) {
    if (!category || typeof category !== 'string' || category.trim() === '')
      errors.push('category is required and must be a non-empty string');
  }
  if (requireAll || stock !== undefined) {
    if (stock === undefined || stock === null || stock === '')
      errors.push('stock is required');
    else if (!Number.isSafeInteger(stock) || Number(stock) < 0)
      errors.push('stock must be a non-negative integer');
  }
  if (requireAll || price_cents !== undefined) {
    if (price_cents === undefined || price_cents === null || price_cents === '')
      errors.push('price_cents is required');
    else if (!Number.isSafeInteger(price_cents) || Number(price_cents) < 0)
      errors.push('price_cents must be a non-negative integer');
  }
  return errors;
}

// GET /api/products
router.get('/', (req, res) => {
  try {
    const db = getDb();
    const { search, category } = req.query;
    let sql = 'SELECT * FROM products WHERE 1=1';
    const params = [];
    if (search) {
      sql += ' AND (LOWER(name) LIKE ? OR LOWER(sku) LIKE ?)';
      const term = `%${String(search).toLowerCase()}%`;
      params.push(term, term);
    }
    if (category) {
      sql += ' AND LOWER(category) = ?';
      params.push(String(category).toLowerCase());
    }
    sql += ' ORDER BY id ASC';
    const products = db.prepare(sql).all(...params);
    res.json(products);
  } catch (err) {
    res.status(err.statusCode || 500).json({ message: err.message });
  }
});

// POST /api/products
router.post('/', (req, res) => {
  try {
    const db = getDb();
    const errors = validateProduct(req.body, true);
    if (errors.length > 0)
      return res.status(400).json({ message: errors.join('; ') });

    const { sku, name, category, stock, price_cents } = req.body;
    const stockInt = Number(stock);
    const priceInt = Number(price_cents);

    const existing = db.prepare('SELECT id FROM products WHERE sku = ?').get(sku.trim());
    if (existing)
      return res.status(409).json({ message: `Duplicate SKU: "${sku.trim()}" already exists` });

    const created = withTransaction(db, () => {
    const result = db.prepare(`
      INSERT INTO products (sku, name, category, stock, price_cents)
      VALUES (?, ?, ?, ?, ?)
    `).run(sku.trim(), name.trim(), category.trim(), stockInt, priceInt);

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(result.lastInsertRowid);

    db.prepare(`
      INSERT INTO audit_log (entity_type, entity_id, action, detail)
      VALUES ('product', ?, 'created', ?)
    `).run(product.id, JSON.stringify({ sku: product.sku, name: product.name, category: product.category, stock: product.stock, price_cents: product.price_cents }));

    return product;
    });
    res.status(201).json(created);
  } catch (err) {
    if (err.message && err.message.includes('UNIQUE')) {
      return res.status(409).json({ message: 'Duplicate SKU' });
    }
    res.status(err.statusCode || 500).json({ message: err.message });
  }
});

// PATCH /api/products/:id
router.patch('/:id', (req, res) => {
  try {
    const db = getDb();
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0)
      return res.status(400).json({ message: 'Invalid product id' });

    const { version } = req.body ?? {};
    if (version === undefined || version === null)
      return res.status(400).json({ message: 'version is required for optimistic concurrency control' });
    const versionInt = Number(version);
    if (!Number.isSafeInteger(version) || versionInt < 1)
      return res.status(400).json({ message: 'version must be a positive integer' });

    const current = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!current)
      return res.status(404).json({ message: `Product ${id} not found` });

    if (current.version !== versionInt)
      return res.status(409).json({ message: `Stale version: expected ${current.version}, got ${versionInt}` });

    const errors = validateProduct(req.body, false);
    if (errors.length > 0)
      return res.status(400).json({ message: errors.join('; ') });

    const updatedSku       = req.body.sku       !== undefined ? req.body.sku.trim()       : current.sku;
    const updatedName      = req.body.name      !== undefined ? req.body.name.trim()      : current.name;
    const updatedCategory  = req.body.category  !== undefined ? req.body.category.trim()  : current.category;
    const updatedStock     = req.body.stock     !== undefined ? Number(req.body.stock)     : current.stock;
    const updatedPrice     = req.body.price_cents !== undefined ? Number(req.body.price_cents) : current.price_cents;

    if (updatedSku !== current.sku) {
      const dupCheck = db.prepare('SELECT id FROM products WHERE sku = ? AND id != ?').get(updatedSku, id);
      if (dupCheck)
        return res.status(409).json({ message: `Duplicate SKU: "${updatedSku}" already exists` });
    }

    const saved = withTransaction(db, () => {
    const result = db.prepare(`
      UPDATE products
      SET sku=?, name=?, category=?, stock=?, price_cents=?, version=version+1, updated_at=datetime('now')
      WHERE id=? AND version=?
    `).run(updatedSku, updatedName, updatedCategory, updatedStock, updatedPrice, id, versionInt);

    if (result.changes === 0)
      throw Object.assign(new Error('Concurrent modification detected — please reload and retry'), {statusCode:409});

    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(id);

    db.prepare(`
      INSERT INTO audit_log (entity_type, entity_id, action, detail)
      VALUES ('product', ?, 'updated', ?)
    `).run(id, JSON.stringify({ before: { sku: current.sku, name: current.name, category: current.category, stock: current.stock, price_cents: current.price_cents, version: current.version }, after: { sku: updated.sku, name: updated.name, category: updated.category, stock: updated.stock, price_cents: updated.price_cents, version: updated.version } }));

    return updated;
    });
    res.json(saved);
  } catch (err) {
    if (err.message && err.message.includes('UNIQUE')) {
      return res.status(409).json({ message: 'Duplicate SKU' });
    }
    res.status(err.statusCode || 500).json({ message: err.message });
  }
});

export default router;