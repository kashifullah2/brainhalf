import express from 'express';
import { pathToFileURL } from 'node:url';
import { getDb } from './db.js';
import healthRouter from './routes/health.js';
import productsRouter from './routes/products.js';
import reservationsRouter from './routes/reservations.js';
import auditRouter from './routes/audit.js';

const PORT = process.env.PORT || 3001;

const app = express();


app.use(express.json());

// Initialize DB eagerly
try {
  getDb();
  console.log('[server] Database initialized.');
} catch (err) {
  console.error('[server] Fatal: could not initialize database:', err.message);
  process.exit(1);
}

app.use('/api/health',       healthRouter);
app.use('/api/products',     productsRouter);
app.use('/api/reservations', reservationsRouter);
app.use('/api/audit',        auditRouter);

// 404 for unknown API routes
app.use('/api', (_req, res) => {
  res.status(404).json({ message: 'Unknown API endpoint' });
});

app.use((error, _req, res, _next) => {
  res.status(error.status || 500).json({message: error.type === 'entity.parse.failed' ? 'Invalid JSON body' : error.message});
});
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  app.listen(PORT, '127.0.0.1', () => console.log(`[server] Stockroom QA API listening on http://127.0.0.1:${PORT}`));
}

export default app;