import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
if(!isMainThread){
 process.env.STOCKROOM_DB=workerData.dbPath;
 const {default:router}=await import('../routes/reservations.js');
 const {closeDb}=await import('../db.js');
 parentPort.on('message',()=>{
  const result={status:200,body:null};const response={status(n){result.status=n;return this},json(b){result.body=JSON.parse(JSON.stringify(b));return this}};
  try{const path=workerData.action==='create'?'/':'/:id/cancel';const route=router.stack.find(s=>s.route?.methods.post&&s.route.path===path);route.route.stack[0].handle({body:workerData.body,headers:workerData.headers||{},params:{id:String(workerData.id)}},response);parentPort.postMessage(result)}catch(e){parentPort.postMessage({error:e.message})}finally{closeDb();parentPort.close()}
 });parentPort.postMessage('ready');
}else{
 const dir=mkdtempSync(join(tmpdir(),'stockroom-concurrency-'));const dbPath=join(dir,'test.db');process.env.STOCKROOM_DB=dbPath;
 const {getDb,closeDb}=await import('../db.js');
 const db=getDb();
 async function compete(inputs){const workers=inputs.map(input=>new Worker(new URL(import.meta.url),{workerData:{dbPath,...input}}));
  try{await Promise.all(workers.map(w=>new Promise((resolve,reject)=>{w.once('message',resolve);w.once('error',reject)})));return await Promise.all(workers.map(w=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Worker timed out')),10000);w.once('message',r=>{clearTimeout(timer);resolve(r)});w.once('error',e=>{clearTimeout(timer);reject(e)});w.postMessage('go')})))}finally{await Promise.all(workers.map(w=>w.terminate()))}}
 const body=id=>({product_id:id,customer_name:'Concurrent customer',customer_email:'concurrent@example.com',quantity:1});
 try{
  const insert=db.prepare('INSERT INTO products (sku,name,category,stock,price_cents) VALUES (?,?,?,?,?)');
  const scarce=Number(insert.run('CONCURRENT-1','Scarce camera','Video',1,2500).lastInsertRowid);
  const first=await compete([{action:'create',body:body(scarce)},{action:'create',body:body(scarce)}]);assert.deepEqual(first.map(r=>r.status).sort(),[201,409]);assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(scarce).stock,0);console.log('PASS two workers competing for the last item');
  const replay=Number(insert.run('CONCURRENT-2','Recorder','Audio',3,2500).lastInsertRowid);
  const second=await compete([1,2].map(()=>({action:'create',body:body(replay),headers:{'idempotency-key':'concurrent-key'}})));assert.deepEqual(second.map(r=>r.status).sort(),[200,201]);assert.equal(second[0].body.id,second[1].body.id);assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(replay).stock,2);console.log('PASS two workers using the same idempotency key');
  const third=await compete([1,2].map(()=>({action:'cancel',id:second[0].body.id})));assert.deepEqual(third.map(r=>r.status),[200,200]);assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(replay).stock,3);assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_log WHERE entity_type='reservation' AND entity_id=? AND action='cancelled'").get(second[0].body.id).n,1);console.log('PASS two workers canceling the same reservation');
 }finally{closeDb();delete process.env.STOCKROOM_DB;rmSync(dir,{recursive:true,force:true})}
}
