import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
const root=resolve(process.argv[2] || process.cwd());
const results=[];
async function fixture(){
 const dir=mkdtempSync(join(root,'.qa-'));
 cpSync(join(root,'server'),join(dir,'server'),{recursive:true});
 const modules={};
 for(const name of ['health','products','reservations','audit'])modules[name]=(await import(pathToFileURL(join(dir,'server/routes',name+'.js')))).default;
 const {getDb}=await import(pathToFileURL(join(dir,'server/db.js')));
 const request=async(method,url,body={},headers={})=>{
  const parsed=new URL(url,'http://local'); const [,,group,...parts]=parsed.pathname.split('/');
  const pathname='/'+parts.join('/');
  const match=modules[group]?.stack.find(l=>l.route?.methods[method.toLowerCase()]&&new RegExp('^'+l.route.path.replace(/:[^/]+/g,'([^/]+)')+'$').test(pathname));
  if(!match)return {status:404,body:{message:'Route not found'}};
  const names=(match.route.path.match(/:[^/]+/g)||[]).map(n=>n.slice(1));
  const captures=pathname.match(new RegExp('^'+match.route.path.replace(/:[^/]+/g,'([^/]+)')+'$')).slice(1);
  const req={body,headers:Object.fromEntries(Object.entries(headers).map(([k,v])=>[k.toLowerCase(),v])),params:Object.fromEntries(names.map((n,i)=>[n,captures[i]])),query:Object.fromEntries(parsed.searchParams)};
  const result={status:200,body:null};const res={status(n){result.status=n;return this},json(b){result.body=JSON.parse(JSON.stringify(b));return this}};
  await match.route.stack[0].handle(req,res);return result;
 };
 return {request,getDb,dir,close(){try{getDb().close()}catch{}rmSync(dir,{recursive:true,force:true})}};
}
function status(r,n){assert.equal(r.status,n,JSON.stringify(r.body));return r.body}
const product={sku:'QA-01',name:'Field recorder',category:'Audio',stock:3,price_cents:2500};
const reservation=(id=1)=>({product_id:id,customer_name:'Audit Customer',customer_email:'audit@example.com',quantity:1});
const cases=[
 ['Health and required seed',async({request:r})=>{assert.equal(status(await r('GET','/api/health'),200).status,'ok');const p=status(await r('GET','/api/products'),200).find(p=>p.sku==='CAMERA-01');assert.equal(p.stock,3);assert.equal(p.price_cents,2500)}],
 ['Create, search and category filter',async({request:r})=>{status(await r('POST','/api/products',product),201);assert.equal(status(await r('GET','/api/products?search=recorder&category=audio'),200).length,1);assert.equal(status(await r('GET','/api/products?search=missing'),200).length,0)}],
 ['Duplicate SKU returns 409',async({request:r})=>{status(await r('POST','/api/products',product),201);status(await r('POST','/api/products',product),409)}],
 ['Reject negative/fractional product stock and price',async({request:r})=>{for(const bad of [{stock:-1},{stock:1.5},{price_cents:-1},{price_cents:1.5}])status(await r('POST','/api/products',{...product,...bad}),400)}],
 ['Reject boolean/array/object numeric fields',async({request:r})=>{for(const bad of [{stock:true},{stock:[]},{price_cents:{}},{price_cents:false}])status(await r('POST','/api/products',{...product,...bad}),400)}],
 ['Product edits reject stale version',async({request:r})=>{const p=status(await r('POST','/api/products',product),201);const edited=status(await r('PATCH','/api/products/'+p.id,{name:'New name',version:1}),200);assert.equal(edited.version,2);status(await r('PATCH','/api/products/'+p.id,{name:'Overwrite',version:1}),409)}],
 ['Product edit rejects duplicate SKU',async({request:r})=>{const p=status(await r('POST','/api/products',product),201);status(await r('PATCH','/api/products/'+p.id,{sku:'CAMERA-01',version:1}),409)}],
 ['Reject invalid reservation email and quantity',async({request:r})=>{for(const bad of [{customer_email:'bad'},{quantity:0},{quantity:-1},{quantity:1.2}])status(await r('POST','/api/reservations',{...reservation(),...bad}),400)}],
 ['Reject reservation numeric and email type coercion',async({request:r})=>{for(const bad of [{quantity:true},{quantity:[1]},{customer_email:['audit@example.com']},{product_id:true}])status(await r('POST','/api/reservations',{...reservation(),...bad}),400)}],
 ['Valid reservation reduces stock atomically',async({request:r})=>{const res=status(await r('POST','/api/reservations',reservation()),201);assert.equal(res.status,'pending');assert.equal(status(await r('GET','/api/products'),200)[0].stock,2)}],
 ['Reservation increments product version',async({request:r})=>{status(await r('POST','/api/reservations',reservation()),201);assert.equal(status(await r('GET','/api/products'),200)[0].version,2);status(await r('PATCH','/api/products/1',{stock:3,version:1}),409)}],
 ['Overselling returns 409 and leaves stock/audit unchanged',async({request:r})=>{const before=status(await r('GET','/api/audit'),200);status(await r('POST','/api/reservations',{...reservation(),quantity:4}),409);assert.equal(status(await r('GET','/api/products'),200)[0].stock,3);assert.deepEqual(status(await r('GET','/api/audit'),200),before)}],
 ['Idempotent replay preserves reservation ID and stock',async({request:r})=>{const h={'Idempotency-Key':'same'};const a=status(await r('POST','/api/reservations',reservation(),h),201);const b=status(await r('POST','/api/reservations',reservation(),h),200);assert.equal(a.id,b.id);assert.equal(status(await r('GET','/api/products'),200)[0].stock,2)}],
 ['Changed idempotent payload returns 409',async({request:r})=>{const h={'Idempotency-Key':'same'};status(await r('POST','/api/reservations',reservation(),h),201);status(await r('POST','/api/reservations',{...reservation(),quantity:2},h),409)}],
 ['Confirm and repeat confirm are idempotent',async({request:r})=>{const a=status(await r('POST','/api/reservations',reservation()),201);for(let i=0;i<2;i++)assert.equal(status(await r('POST',`/api/reservations/${a.id}/confirm`),200).status,'confirmed');assert.equal(status(await r('GET','/api/products'),200)[0].stock,2);assert.equal(status(await r('GET',`/api/audit?entity_type=reservation&entity_id=${a.id}`),200).filter(e=>e.action==='confirmed').length,1)}],
 ['Cancel twice restores stock exactly once and bumps version',async({request:r})=>{const a=status(await r('POST','/api/reservations',reservation()),201);for(let i=0;i<2;i++)status(await r('POST',`/api/reservations/${a.id}/cancel`),200);const p=status(await r('GET','/api/products'),200)[0];assert.equal(p.stock,3);assert.equal(p.version,3);status(await r('POST',`/api/reservations/${a.id}/confirm`),409)}],
 ['Confirm then cancel restores stock',async({request:r})=>{const a=status(await r('POST','/api/reservations',reservation()),201);status(await r('POST',`/api/reservations/${a.id}/confirm`),200);status(await r('POST',`/api/reservations/${a.id}/cancel`),200);assert.equal(status(await r('GET','/api/products'),200)[0].stock,3)}],
 ['Sequential competing reservations cannot oversell',async({request:r})=>{const p=status(await r('POST','/api/products',{...product,stock:1}),201);status(await r('POST','/api/reservations',reservation(p.id)),201);status(await r('POST','/api/reservations',reservation(p.id)),409);assert.equal(status(await r('GET','/api/products?search=QA-01'),200)[0].stock,0)}],
 ['Edit metadata while available stock is below reserved quantity',async({request:r})=>{status(await r('POST','/api/reservations',{...reservation(),quantity:3}),201);const p=status(await r('GET','/api/products'),200)[0];const edited=status(await r('PATCH','/api/products/1',{name:'Renamed Camera',version:p.version}),200);assert.equal(edited.stock,0)}],
 ['Unknown IDs return 404 and invalid IDs return 400',async({request:r})=>{status(await r('PATCH','/api/products/999999',{version:1,name:'Test'}),404);status(await r('POST','/api/reservations',reservation(999999)),404);status(await r('POST','/api/reservations/999999/cancel'),404);status(await r('POST','/api/reservations/abc/confirm'),400)}],
 ['Audit reports the real changes',async({request:r})=>{const p=status(await r('POST','/api/products',product),201);status(await r('PATCH','/api/products/'+p.id,{name:'Revised',version:1}),200);const a=status(await r('GET',`/api/audit?entity_type=product&entity_id=${p.id}`),200);assert.deepEqual(a.map(e=>e.action),['updated','created'])}],
 ['Invalid audit pagination returns 400',async({request:r})=>{for(const query of ['limit=abc','limit=-1','offset=1.5','entity_id=not-an-id'])status(await r('GET','/api/audit?'+query),400)}],
 ['SQLite data persists after closing and reopening database',async({request:r,getDb,dir})=>{const p=status(await r('POST','/api/products',product),201);getDb().close();const db=new DatabaseSync(join(dir,'data/stockroom.db'));try{assert.equal(db.prepare('SELECT name FROM products WHERE id=?').get(p.id).name,product.name)}finally{db.close()}}],
 ['Product creation rolls back if audit write fails',async({request:r,getDb})=>{getDb().exec("CREATE TRIGGER fail_audit BEFORE INSERT ON audit_log WHEN NEW.entity_type='product' BEGIN SELECT RAISE(ABORT, 'intentional test failure'); END;");assert.match(status(await r('POST','/api/products',product),500).message,/intentional test failure/);assert.equal(status(await r('GET','/api/products?search=QA-01'),200).length,0)}],
 ['Product edit rolls back if audit write fails',async({request:r,getDb})=>{const p=status(await r('POST','/api/products',product),201);getDb().exec("CREATE TRIGGER fail_audit BEFORE INSERT ON audit_log WHEN NEW.entity_type='product' BEGIN SELECT RAISE(ABORT, 'intentional test failure'); END;");assert.match(status(await r('PATCH','/api/products/'+p.id,{name:'Must roll back',version:1}),500).message,/intentional test failure/);const current=status(await r('GET','/api/products?search=QA-01'),200)[0];assert.equal(current.name,product.name);assert.equal(current.version,1)}],
 ['Database rolls back reservation if audit write fails',async({request:r,getDb})=>{getDb().exec("CREATE TRIGGER fail_audit BEFORE INSERT ON audit_log WHEN NEW.entity_type='reservation' BEGIN SELECT RAISE(ABORT, 'intentional test failure'); END;");assert.match(status(await r('POST','/api/reservations',reservation()),500).message,/intentional test failure/);assert.equal(status(await r('GET','/api/products'),200)[0].stock,3);assert.equal(status(await r('GET','/api/reservations'),200).length,0)}]
];
for(const [name,test]of cases){let f;try{f=await fixture();await test(f);results.push({name,pass:true});console.log('PASS',name)}catch(e){results.push({name,pass:false,error:e.message});console.log('FAIL',name,e.message.split('\n')[0])}finally{f?.close()}}
const output={mode:'actual route handlers + real SQLite; no HTTP transport or true concurrent requests',passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,results};
writeFileSync(process.argv[3]||join(root,'qa-results.json'),JSON.stringify(output,null,2));console.log(JSON.stringify({passed:output.passed,failed:output.failed}));process.exitCode=output.failed?1:0;
