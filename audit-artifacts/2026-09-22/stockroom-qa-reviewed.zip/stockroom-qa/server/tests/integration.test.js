// Compatibility entry for the original export's test command.
import './http.test.js';
