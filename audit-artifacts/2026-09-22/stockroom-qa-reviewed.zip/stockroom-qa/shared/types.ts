export interface Product {
  id: number;
  sku: string;
  name: string;
  category: string;
  stock: number;
  price_cents: number;
  version: number;
  created_at: string;
  updated_at: string;
}

export interface Reservation {
  id: number;
  product_id: number;
  customer_name: string;
  customer_email: string;
  quantity: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  idempotency_key: string | null;
  product_name: string;
  product_sku: string;
  price_cents: number;
  created_at: string;
  updated_at: string;
}

export interface AuditEntry {
  id: number;
  entity_type: string;
  entity_id: number;
  action: string;
  actor: string;
  detail: string | null;
  created_at: string;
}

export interface ApiError {
  message: string;
}

export interface HealthStatus {
  status: 'ok' | 'error';
  timestamp?: string;
  message?: string;
}