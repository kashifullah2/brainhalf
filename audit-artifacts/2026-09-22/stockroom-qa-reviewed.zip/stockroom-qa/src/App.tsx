import { useCallback, useEffect, useState } from 'react';
import { Package, LayoutDashboard, ClipboardList, History, Sun, Moon } from 'lucide-react';
import Inventory from './components/Inventory';
import Dashboard from './components/Dashboard';
import Reservations from './components/Reservations';
import Audit from './components/Audit';
import ConnectionBanner from './components/ConnectionBanner';
import { useHealth } from './hooks/useHealth';
import { api } from './api';
import type { Product, Reservation, AuditEntry } from '../shared/types';
const views=[['Overview',LayoutDashboard],['Inventory',Package],['Reservations',ClipboardList],['Audit history',History]] as const;
export default function App(){
 const [view,setView]=useState<string>('Overview');
 const [theme,setTheme]=useState(()=>{try{return localStorage.getItem('stockroom-theme')||'light'}catch{return 'light'}});
 const health=useHealth();
 const [data,setData]=useState<{products:Product[];reservations:Reservation[];auditEntries:AuditEntry[]}|null>(null);
 const [error,setError]=useState('');const [loading,setLoading]=useState(false);
 useEffect(()=>{document.documentElement.dataset.theme=theme;try{localStorage.setItem('stockroom-theme',theme)}catch{}},[theme]);
 const refresh=useCallback(async()=>{setLoading(true);setError('');try{const [products,reservations,auditEntries]=await Promise.all([api.getProducts(),api.getReservations(),api.getAudit()]);setData({products,reservations,auditEntries})}catch(e){setError(e instanceof Error?e.message:'Could not load the equipment desk')}finally{setLoading(false)}},[]);
 useEffect(()=>{if(view==='Overview'&&health.state==='connected')void refresh()},[view,health.state,refresh]);
 return <div className="app-shell">
  <a className="skip-link" href="#main">Skip to content</a>
  <aside className="sidebar"><div className="sidebar-logo"><Package aria-hidden="true" size={28}/><h1>Stockroom <span>QA</span></h1><p>Equipment desk</p></div>
   <nav className="sidebar-nav" aria-label="Main navigation">{views.map(([label,Icon])=><button key={label} className={'nav-item'+(view===label?' active':'')} aria-current={view===label?'page':undefined} onClick={()=>setView(label)}><Icon size={18}/>{label}</button>)}</nav>
   <button className="nav-item theme-switch" onClick={()=>setTheme(theme==='dark'?'light':'dark')}>{theme==='dark'?<Sun size={18}/>:<Moon size={18}/>}Use {theme==='dark'?'light':'dark'} mode</button>
  </aside>
  <main className="main-content" id="main" tabIndex={-1}>
   <ConnectionBanner state={health.state} lastChecked={health.lastChecked} onRecheck={health.recheck}/>
   {view==='Overview'&&<><header className="page-header"><div><p className="eyebrow">Equipment desk</p><h2>Ready for the next checkout.</h2><p className="muted">Availability, reservations, and every change in one place.</p></div><button className="btn btn-secondary" onClick={refresh} disabled={loading}>Refresh overview</button></header><div className="page-body">
   {error&&<p role="alert" className="alert alert-error">{error}</p>}
   {loading?<p role="status">Loading overview…</p>:data?<Dashboard {...data}/>:<div className="empty-state"><Package size={40}/><p>Connect the API to see your equipment and reservations.</p></div>}
   </div></>}
   {view==='Inventory'&&<Inventory/>}{view==='Reservations'&&<Reservations/>}{view==='Audit history'&&<Audit/>}
  </main>
 </div>;
}
