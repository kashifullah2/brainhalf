import type { Product, Reservation, AuditEntry, HealthStatus } from '../shared/types';

const BASE = '/api';

async function request<T>(
  path: string,
  options: RequestInit = {},
  extraHeaders: Record<string, string> = {}
): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...extraHeaders,
      ...(options.headers as Record<string, string> | undefined ?? {}),
    },
  });

  let body: unknown;
  const contentType = res.headers.get('content-type') ?? '';
  if (contentType.includes('application/json')) {
    body = await res.json();
  } else {
    body = { message: await res.text() };
  }

  if (!res.ok) {
    const details = body !== null && typeof body === 'object' ? body as {message?: string; error?: string; code?: string} : {};
    const msg = details.code === 'BACKEND_NOT_RUNNING' ? 'The hosted preview cannot run this backend. Export the app and start it locally with npm run dev.' : details.message || details.error || `HTTP ${res.status}`;
    const err = new Error(msg);
    (err as Error & { status: number }).status = res.status;
    throw err;
  }

  return body as T;
}

export const api = {
  health(): Promise<HealthStatus> {
    return request<HealthStatus>('/health');
  },

  getProducts(params?: { search?: string; category?: string }): Promise<Product[]> {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.category) qs.set('category', params.category);
    const q = qs.toString();
    return request<Product[]>(`/products${q ? `?${q}` : ''}`);
  },

  createProduct(data: Omit<Product, 'id' | 'version' | 'created_at' | 'updated_at'>): Promise<Product> {
    return request<Product>('/products', { method: 'POST', body: JSON.stringify(data) });
  },

  updateProduct(id: number, data: Partial<Omit<Product, 'id' | 'created_at' | 'updated_at'>> & { version: number }): Promise<Product> {
    return request<Product>(`/products/${id}`, { method: 'PATCH', body: JSON.stringify(data) });
  },

  getReservations(): Promise<Reservation[]> {
    return request<Reservation[]>('/reservations');
  },

  createReservation(
    data: { product_id: number; customer_name: string; customer_email: string; quantity: number },
    idempotencyKey?: string
  ): Promise<Reservation> {
    const extra: Record<string, string> = {};
    if (idempotencyKey) extra['Idempotency-Key'] = idempotencyKey;
    return request<Reservation>('/reservations', { method: 'POST', body: JSON.stringify(data) }, extra);
  },

  confirmReservation(id: number): Promise<Reservation> {
    return request<Reservation>(`/reservations/${id}/confirm`, { method: 'POST' });
  },

  cancelReservation(id: number): Promise<Reservation> {
    return request<Reservation>(`/reservations/${id}/cancel`, { method: 'POST' });
  },

  getAudit(params?: { entity_type?: string; entity_id?: number; limit?: number }): Promise<AuditEntry[]> {
    const qs = new URLSearchParams();
    if (params?.entity_type) qs.set('entity_type', params.entity_type);
    if (params?.entity_id !== undefined) qs.set('entity_id', String(params.entity_id));
    if (params?.limit !== undefined) qs.set('limit', String(params.limit));
    const q = qs.toString();
    return request<AuditEntry[]>(`/audit${q ? `?${q}` : ''}`);
  },
};