import { useState, type FormEvent } from 'react';
import type { Product } from '../../shared/types';
import { api } from '../api';
import Modal from './Modal';
export default function ProductFormModal({product,onSave,onClose}:{product:Product|null;onSave:(p:Product)=>void;onClose:()=>void}){
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 async function save(event:FormEvent<HTMLFormElement>){
  event.preventDefault();if(busy)return;const form=new FormData(event.currentTarget);
  const data={sku:String(form.get('sku')).trim(),name:String(form.get('name')).trim(),category:String(form.get('category')).trim(),stock:Number(form.get('stock')),price_cents:Number(form.get('price_cents'))};
  setBusy(true);setError('');try{const saved=product?await api.updateProduct(product.id,{...data,version:product.version}):await api.createProduct(data);onSave(saved)}catch(e){setError((e instanceof Error?e.message:'Could not save product')+'. If the version changed, close this form and refresh inventory before editing again.')}finally{setBusy(false)}
 }
 return <Modal title={product?'Edit product':'Add product'} busy={busy} onClose={onClose}><form onSubmit={save}><div className="modal-body form-grid">
 {error&&<p className="alert alert-error" role="alert">{error}</p>}
 <label className="form-group">SKU<input autoFocus className="form-input" name="sku" required maxLength={80} defaultValue={product?.sku}/></label>
 <label className="form-group">Product name<input className="form-input" name="name" required maxLength={160} defaultValue={product?.name}/></label>
 <label className="form-group">Category<input className="form-input" name="category" required maxLength={80} defaultValue={product?.category}/></label>
 <div className="form-grid form-grid-2"><label className="form-group">Available stock<input className="form-input" name="stock" type="number" required min="0" step="1" defaultValue={product?.stock??0}/></label>
 <label className="form-group">Unit price (cents)<input className="form-input" name="price_cents" type="number" required min="0" step="1" defaultValue={product?.price_cents??0}/></label></div>
 <p className="form-hint">Available stock excludes equipment already reserved. Enter 2500 for $25.00.</p></div>
 <footer className="modal-footer"><button type="button" className="btn btn-secondary" disabled={busy} onClick={onClose}>Cancel</button><button className="btn btn-primary" disabled={busy}>{busy?'Saving…':'Save product'}</button></footer>
 </form></Modal>;
}
