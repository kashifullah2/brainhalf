import { Wifi, WifiOff, RefreshCw, Loader2 } from 'lucide-react';
import type { ConnectionState } from '../hooks/useHealth';

interface Props {
  state: ConnectionState;
  lastChecked: string | null;
  onRecheck: () => void;
}

export default function ConnectionBanner({ state, lastChecked, onRecheck }: Props) {
  if (state === 'connected') {
    return (
      <div className="conn-banner conn-ok">
        <Wifi size={14} />
        <span>API connected{lastChecked ? ` · checked ${lastChecked}` : ''}</span>
        <button className="conn-refresh" onClick={onRecheck} title="Re-check connection" aria-label="Re-check connection">
          <RefreshCw size={12} />
        </button>
      </div>
    );
  }

  if (state === 'checking') {
    return (
      <div className="conn-banner conn-checking">
        <Loader2 size={14} className="spin" />
        <span>Connecting to API…</span>
      </div>
    );
  }

  return (
    <div className="conn-banner conn-error">
      <WifiOff size={14} />
      <span>
        <strong>API offline.</strong> Start the server locally:&nbsp;
        <code>npm run dev</code>&nbsp;(requires Node&nbsp;≥&nbsp;22.18)
      </span>
      <button className="conn-refresh" onClick={onRecheck} title="Re-check connection" aria-label="Re-check connection">
        <RefreshCw size={12} />
      </button>
    </div>
  );
}