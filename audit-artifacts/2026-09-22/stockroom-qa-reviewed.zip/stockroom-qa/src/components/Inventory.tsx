import { useState, useEffect, useCallback, useRef } from 'react';
import { Plus, Search, Pencil, Loader2, PackageOpen, RefreshCw, X } from 'lucide-react';
import { api } from '../api';
import type { Product } from '../../shared/types';
import ProductFormModal from './ProductFormModal';

function formatCents(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

function stockClass(stock: number): string {
  if (stock === 0) return 'stock-zero';
  if (stock <= 2) return 'stock-low';
  return '';
}

export default function Inventory() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [categories, setCategories] = useState<string[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editTarget, setEditTarget] = useState<Product | null>(null);

  const requestId = useRef(0);
  const load = useCallback(async () => {
    const currentRequest = ++requestId.current;
    setLoading(true);
    setError(null);
    try {
      const data = await api.getProducts({ search: search || undefined, category: categoryFilter || undefined });
      if (currentRequest !== requestId.current) return;
      setProducts(data);
      // Rebuild category list from all products (no filter) only if no filter active
      if (!search && !categoryFilter) {
        const cats = Array.from(new Set(data.map((p) => p.category))).sort();
        setCategories(cats);
      }
    } catch (err) {
      if (currentRequest === requestId.current) setError(err instanceof Error ? err.message : 'Failed to load products');
    } finally {
      if (currentRequest === requestId.current) setLoading(false);
    }
  }, [search, categoryFilter]);

  const loadAllCategories = useCallback(async () => {
    try {
      const all = await api.getProducts();
      const cats = Array.from(new Set(all.map((p) => p.category))).sort();
      setCategories(cats);
    } catch {
      // non-fatal
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    loadAllCategories();
  }, [loadAllCategories]);

  function handleAddProduct() {
    setEditTarget(null);
    setShowModal(true);
  }

  function handleEditProduct(product: Product) {
    setEditTarget(product);
    setShowModal(true);
  }

  async function handleModalSave(saved: Product) {
    setShowModal(false);
    setEditTarget(null);
    await load();
    await loadAllCategories();
    // Suppress unused warning; saved is returned for callers who might use it
    void saved;
  }

  function handleModalClose() {
    setShowModal(false);
    setEditTarget(null);
  }

  function handleClearSearch() {
    setSearch('');
    setCategoryFilter('');
  }

  return (
    <>
      <div className="page-header">
        <h2>Inventory</h2>
        <div className="page-header-actions">
          <button className="btn btn-secondary btn-sm" onClick={load} disabled={loading} title="Refresh">
            <RefreshCw size={14} className={loading ? 'spin' : ''} />
            Refresh
          </button>
          <button className="btn btn-primary" onClick={handleAddProduct}>
            <Plus size={15} />
            Add product
          </button>
        </div>
      </div>

      <div className="page-body">
        {error && (
          <div className="alert alert-error" role="alert">
            <X size={15} />
            <span>{error}</span>
            <button className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }} onClick={load}>Retry</button>
          </div>
        )}

        <div className="filters-bar">
          <div className="search-input-wrap">
            <Search size={14} />
            <input
              className="search-input"
              type="text"
              placeholder="Search SKU or name…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search products"
            />
          </div>
          <select
            className="filter-select"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            aria-label="Filter by category"
          >
            <option value="">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c.toLowerCase()}>{c}</option>
            ))}
          </select>
          {(search || categoryFilter) && (
            <button className="btn btn-ghost btn-sm" onClick={handleClearSearch}>
              <X size={13} /> Clear
            </button>
          )}
        </div>

        {loading ? (
          <div className="spinner-wrap">
            <Loader2 size={28} className="spin" />
          </div>
        ) : products.length === 0 ? (
          <div className="empty-state">
            <PackageOpen size={40} />
            <p>
              {search || categoryFilter
                ? 'No products match your filters.'
                : 'No products yet. Add your first item.'}
            </p>
            {!search && !categoryFilter && (
              <button className="btn btn-primary" onClick={handleAddProduct}>
                <Plus size={14} /> Add product
              </button>
            )}
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>SKU</th>
                  <th>Product name</th>
                  <th>Category</th>
                  <th>Stock</th>
                  <th>Unit price</th>
                  <th>Version</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id}>
                    <td className="td-mono">{product.sku}</td>
                    <td style={{ fontWeight: 500 }}>{product.name}</td>
                    <td>
                      <span className="badge badge-product">{product.category}</span>
                    </td>
                    <td>
                      <span className={stockClass(product.stock)}>
                        {product.stock}
                      </span>
                      {product.stock === 0 && (
                        <span className="badge badge-cancelled" style={{ marginLeft: 8 }}>out</span>
                      )}
                      {product.stock > 0 && product.stock <= 2 && (
                        <span className="badge badge-pending" style={{ marginLeft: 8 }}>low</span>
                      )}
                    </td>
                    <td className="price">{formatCents(product.price_cents)}</td>
                    <td className="td-mono">v{product.version}</td>
                    <td>
                      <div className="td-actions">
                        <button
                          className="btn btn-ghost btn-sm"
                          onClick={() => handleEditProduct(product)}
                          title={`Edit ${product.name}`}
                        >
                          <Pencil size={13} /> Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showModal && (
        <ProductFormModal
          product={editTarget}
          onSave={handleModalSave}
          onClose={handleModalClose}
        />
      )}
    </>
  );
}
