import { useMemo } from 'react';
import {
  Package, ClipboardList, CheckCircle, XCircle,
  AlertTriangle, DollarSign, Clock
} from 'lucide-react';
import type { Product, Reservation, AuditEntry } from '../../shared/types';

interface Props {
  products: Product[];
  reservations: Reservation[];
  auditEntries: AuditEntry[];
}

function StatCard({
  icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  accent?: 'blue' | 'green' | 'yellow' | 'red' | 'purple';
}) {
  return (
    <div className={`stat-card${accent ? ` stat-${accent}` : ''}`}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-body">
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
        {sub && <div className="stat-sub">{sub}</div>}
      </div>
    </div>
  );
}

function formatCents(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z').toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function actionBadgeClass(action: string): string {
  if (action === 'created') return 'badge badge-product';
  if (action === 'confirmed') return 'badge badge-confirmed';
  if (action === 'cancelled') return 'badge badge-cancelled';
  if (action === 'updated') return 'badge badge-reservation';
  return 'badge badge-pending';
}

export default function Dashboard({ products, reservations, auditEntries }: Props) {
  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalStock = products.reduce((s, p) => s + p.stock, 0);
    const lowStock = products.filter((p) => p.stock <= 2).length;
    const totalValue = products.reduce(
      (s, p) => s + p.stock * p.price_cents,
      0
    );
    const pending = reservations.filter((r) => r.status === 'pending').length;
    const confirmed = reservations.filter((r) => r.status === 'confirmed').length;
    const cancelled = reservations.filter((r) => r.status === 'cancelled').length;
    return { totalProducts, totalStock, lowStock, totalValue, pending, confirmed, cancelled };
  }, [products, reservations]);

  const recent = useMemo(
    () => [...auditEntries].slice(0, 12),
    [auditEntries]
  );

  return (
    <>
      <div className="stats-grid">
        <StatCard
          accent="blue"
          icon={<Package size={20} />}
          label="Products"
          value={stats.totalProducts}
          sub={`${stats.totalStock} units in stock`}
        />
        <StatCard
          accent="yellow"
          icon={<AlertTriangle size={20} />}
          label="Low Stock"
          value={stats.lowStock}
          sub="≤ 2 units remaining"
        />
        <StatCard
          accent="green"
          icon={<DollarSign size={20} />}
          label="Inventory Value"
          value={formatCents(stats.totalValue)}
          sub="stock × unit price"
        />
        <StatCard
          accent="purple"
          icon={<ClipboardList size={20} />}
          label="Pending"
          value={stats.pending}
          sub="awaiting confirmation"
        />
        <StatCard
          accent="green"
          icon={<CheckCircle size={20} />}
          label="Confirmed"
          value={stats.confirmed}
        />
        <StatCard
          accent="red"
          icon={<XCircle size={20} />}
          label="Cancelled"
          value={stats.cancelled}
        />
      </div>

      <div className="section-title">Recent Activity</div>
      {recent.length === 0 ? (
        <div className="empty-state" style={{ paddingTop: 24, paddingBottom: 24 }}>
          <Clock size={32} />
          <p>No activity recorded yet.</p>
        </div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Time</th>
                <th>Entity</th>
                <th>ID</th>
                <th>Action</th>
                <th>Actor</th>
                <th>Detail</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((entry) => (
                <tr key={entry.id}>
                  <td className="audit-ts">{formatDate(entry.created_at)}</td>
                  <td>
                    <span
                      className={
                        entry.entity_type === 'product'
                          ? 'badge badge-product'
                          : 'badge badge-reservation'
                      }
                    >
                      {entry.entity_type}
                    </span>
                  </td>
                  <td className="td-mono">#{entry.entity_id}</td>
                  <td>
                    <span className={actionBadgeClass(entry.action)}>
                      {entry.action}
                    </span>
                  </td>
                  <td className="td-mono">{entry.actor}</td>
                  <td>
                    <span className="audit-detail" title={entry.detail ?? ''}>
                      {entry.detail ?? '—'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
