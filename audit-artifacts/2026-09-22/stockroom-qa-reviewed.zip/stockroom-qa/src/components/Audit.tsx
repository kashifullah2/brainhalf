import { useEffect, useState } from 'react';
import { api } from '../api';
import type { AuditEntry } from '../../shared/types';
export default function Audit(){
 const [entries,setEntries]=useState<AuditEntry[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(true),[filter,setFilter]=useState('');
 async function load(){setLoading(true);setError('');try{setEntries(await api.getAudit({limit:1000}))}catch(e){setError(e instanceof Error?e.message:'Could not load audit history')}finally{setLoading(false)}}
 useEffect(()=>{void load()},[]);
 return <><header className="page-header"><div><p className="eyebrow">The record</p><h2>Audit history</h2><p className="muted">The latest 1,000 changes, newest first.</p></div><button className="btn btn-secondary" disabled={loading} onClick={load}>Refresh</button></header><div className="page-body">{error&&<p role="alert" className="alert alert-error">{error}</p>}
 <div className="filters-bar"><label>Record type <select className="filter-select" value={filter} onChange={e=>setFilter(e.target.value)}><option value="">All records</option><option value="product">Products</option><option value="reservation">Reservations</option></select></label></div>
 {loading?<p role="status">Loading audit history…</p>:<ol className="audit-list">{entries.filter(e=>!filter||e.entity_type===filter).map(e=><li key={e.id}><div><span className="td-mono">#{e.id}</span> <strong>{e.entity_type} #{e.entity_id}</strong> <span className="badge">{e.action}</span></div><time dateTime={e.created_at.replace(' ','T')+'Z'}>{new Date(e.created_at.replace(' ','T')+'Z').toLocaleString()}</time><p className="muted">{e.actor}</p>{e.detail&&<details><summary>View changes</summary><pre>{(()=>{try{return JSON.stringify(JSON.parse(e.detail),null,2)}catch{return e.detail}})()}</pre></details>}</li>)}</ol>}
 {!loading&&!error&&entries.length===0&&<p className="empty-state">No changes recorded yet.</p>}</div></>;
}
