import { useEffect, useRef, type ReactNode } from 'react';
export default function Modal({title,busy,onClose,children}:{title:string;busy:boolean;onClose:()=>void;children:ReactNode}){
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const dialog=ref.current;dialog?.showModal();return()=>dialog?.close()},[]);
 return <dialog ref={ref} className="modal-panel" aria-labelledby="dialog-title" onCancel={e=>{e.preventDefault();if(!busy)onClose()}}>
  <header className="modal-header"><h3 id="dialog-title">{title}</h3><button className="btn btn-ghost" type="button" onClick={onClose} disabled={busy} aria-label="Close dialog">Close</button></header>{children}
 </dialog>;
}
