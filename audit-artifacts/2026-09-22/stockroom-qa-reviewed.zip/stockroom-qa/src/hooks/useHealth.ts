import { useState, useEffect, useCallback } from 'react';
import { api } from '../api';

export type ConnectionState = 'checking' | 'connected' | 'disconnected';

export function useHealth() {
  const [state, setState] = useState<ConnectionState>('checking');
  const [lastChecked, setLastChecked] = useState<string | null>(null);

  const check = useCallback(async () => {
    setState('checking');
    try {
      const h = await api.health();
      setState(h.status === 'ok' ? 'connected' : 'disconnected');
      setLastChecked(new Date().toLocaleTimeString());
    } catch {
      setState('disconnected');
      setLastChecked(new Date().toLocaleTimeString());
    }
  }, []);

  useEffect(() => {
    check();
    const interval = setInterval(check, 30_000);
    return () => clearInterval(interval);
  }, [check]);

  return { state, lastChecked, recheck: check };
}