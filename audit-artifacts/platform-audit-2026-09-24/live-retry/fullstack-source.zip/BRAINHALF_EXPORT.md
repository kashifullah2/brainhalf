# Run and deploy your exported project

This export contains your project source. BrainHalf account credentials, sessions, project service tokens and hosted data are not included.

1. Install the dependencies declared in package.json. Review its scripts before running them.
2. Copy .env.example to the local environment file your framework uses and enter your own values. Server secrets must never use VITE_ or NEXT_PUBLIC_ prefixes.
3. Follow your project README and FULLSTACK.md, then run its tests and build before deployment.
4. Provision your own database/storage and configure Google callback URLs and your verified email sender. Data stored on BrainHalf is separate from a source download.


## Export filtering

Local secret files, private keys, build output and dependency caches are omitted. Environment examples contain names and empty values only. Review your source for application-specific credentials before publishing it.
