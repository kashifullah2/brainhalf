export default function App() {
  return <main className="welcome"><p>YOUR WORKSPACE</p><h1>What do you want to build?</h1><p>Describe your application in chat. Your preview will appear here.</p></main>;
}
