# proj-c913bb92-ebd1-444d-b837-a6a512c8e599

Built with [BrainHalf AI Code Studio](https://brainhalf.com).

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```
